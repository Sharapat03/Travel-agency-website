let test = document.getElementById("vid");
test.addEventListener("mouseover", function(event) {
  event.target.style.color = "black";
  setTimeout(function() {
    event.target.style.color = "";
  }, 500);
}, false);



document.querySelector(".btn-danger").addEventListener("click",handleClick);
function handleClick(){
  audio=new Audio('audio/Mouse-Click.mp3');
  audio.play();
};

var numberOfButtons=document.querySelectorAll(".btn-see").length;
  for(var i=0;i<numberOfButtons;i++) {
    document.querySelectorAll(".btn-see")[i].addEventListener("click",function(){
    alert("This function is not working yet");
});
};


const name = document.querySelector('input[type="name"]');
name.addEventListener('focus', (event) => {
  event.target.style.background = '#F0F8FF';
});
name.addEventListener('blur', (event) => {
  event.target.style.background = '';
});


const subject= document.querySelector('input[type="subject"]');
subject.addEventListener('focus', (event1) => {
  event1.target.style.background = '#F0F8FF';});
subject.addEventListener('blur', (event1) => {
  event1.target.style.background = '';
});
